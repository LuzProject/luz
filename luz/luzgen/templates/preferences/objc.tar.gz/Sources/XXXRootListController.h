#import <Preferences/PSListController.h>

@interface REPLACEWITHPREFIXRootListController : PSListController

@end
