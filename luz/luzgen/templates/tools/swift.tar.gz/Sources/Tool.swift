func main() {
    print("Hello, world!")
}