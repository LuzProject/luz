// Copyright (c) 2026 Jaidan Arenas
import Foundation

public func luzLibraryHello() {
    print("Hello from Luz library")
}
