// Copyright (c) 2026 Jaidan Arenas
#import <Foundation/Foundation.h>

void luz_library_hello(void) {
    NSLog(@"Hello from Luz library");
}
