// Copyright (c) 2026 Jaidan Arenas
import Foundation

public func luzFrameworkHello() {
    print("Hello from Luz framework")
}
