// Copyright (c) 2026 Jaidan Arenas
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT void luz_framework_hello(void);
