// Copyright (c) 2026 Jaidan Arenas
#import "Framework.h"

void luz_framework_hello(void) {
    NSLog(@"Hello from Luz framework");
}
